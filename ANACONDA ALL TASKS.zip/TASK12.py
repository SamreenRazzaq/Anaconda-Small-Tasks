# -*- coding: utf-8 -*-
"""
Created on Fri Mar 18 19:54:03 2022

@author: DELL
"""

count=int(input("average of how many numbers: "))
i=1
sum=0
while(i<=count):
    print("enter number: ",i)
    n=int(input())
    sum=sum+n
    i=i+1
    
    
average=sum/count
print("average is ",average)