# -*- coding: utf-8 -*-
"""
Created on Fri Mar 18 19:59:50 2022

@author: DELL
"""

x=int(input("Enter number: "))
for i in range(5):
    if (x>0):
        print("%d is greater than zero" %x)
        
        y=int(input("Enter next number "))
        if (y>0):
            print("%d is also greater than zero"%y)
        elif (y==0):
            print("%d is equal to zero"%y)
        else:
            print("Negative")
            
        break
    if (x<0):
        continue

else:
    print("Negative")