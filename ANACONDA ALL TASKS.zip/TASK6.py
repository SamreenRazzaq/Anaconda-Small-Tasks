# -*- coding: utf-8 -*-
"""
Created on Fri Mar 18 19:47:39 2022

@author: DELL
"""

hour=int(input("enter number in hour",))
week=(1/168)*hour
day=(1/24)*hour
print("number of hour in hour",hour)
print("number of hour in week",week)
print("number of hour in day",day)