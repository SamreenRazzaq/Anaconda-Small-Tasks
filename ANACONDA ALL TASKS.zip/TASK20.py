# -*- coding: utf-8 -*-
"""
Created on Fri Mar 18 20:05:15 2022

@author: DELL
"""

print("Inverted Right angle Triangle")
for i in range(5,0,-1) :
    for j in range(1,i+1):
        print("*",end=' ')
    print()