# -*- coding: utf-8 -*-
"""
Created on Fri Mar 18 20:14:29 2022

@author: DELL
"""

print("Samreen Razzaq, 2021-CE-13, Computer Engineering from UET Lahore")