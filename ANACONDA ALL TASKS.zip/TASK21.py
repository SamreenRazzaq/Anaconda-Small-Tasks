# -*- coding: utf-8 -*-
"""
Created on Fri Mar 18 20:06:02 2022

@author: DELL
"""

print("Inverted Left angle Triangle")
for i in range(5,0,-1) :
    for j in range(1,6-i):
        print(" ",end='')
    for k in range(1,i+1):
        print("*",end='')
    print()