# -*- coding: utf-8 -*-
"""
Created on Fri Mar 18 19:44:37 2022

@author: DELL
"""

x=int(input("enter 1st number: " ))
y=int(input("enter 2nd number: " ))
z=x
x=y
y=z
print("after swaping 1st number become", x )
print("after swaping 2nd number become", y )