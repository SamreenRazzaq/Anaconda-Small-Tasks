# -*- coding: utf-8 -*-
"""
Created on Fri Mar 18 19:51:22 2022

@author: DELL
"""

x=int(input("enter test score: "))
if (x >= 80):
    print("grade A")
elif (x >= 70)and(x <= 79):
    print("grade B")    
elif (x >= 60)and(x <= 69):
    print("grade C")    
elif (x >= 50)and(x <= 59):
    print("grade D")
else:
    print ("grade F")