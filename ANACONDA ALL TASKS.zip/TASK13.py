# -*- coding: utf-8 -*-
"""
Created on Fri Mar 18 19:56:11 2022

@author: DELL
"""

x=int(input("Enter number: "))
for i in range(1,11):
    print("%d*%d=%d"%(x,i,x*i))