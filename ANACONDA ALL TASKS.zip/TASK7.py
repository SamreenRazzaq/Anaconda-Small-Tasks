# -*- coding: utf-8 -*-
"""
Created on Fri Mar 18 19:48:28 2022

@author: DELL
"""

x=int(input("Enter 1st number: ")) 
y=int(input("Enter 2nd number: "))
if (y==x**3):
    print("True")
else:
    print("False")