# -*- coding: utf-8 -*-
"""
Created on Fri Mar 18 19:45:36 2022

@author: DELL
"""

C = int(input("enter temperature in celcius: ",))
F = (9/5)*C + 32
print("temperature in faherenheit is: ",F)