# -*- coding: utf-8 -*-
"""
Created on Fri Mar 18 19:50:23 2022

@author: DELL
"""

x=int(input("enter your salary: "))
y=int(input("enter your scale: "))
if(y>16):
    bonus=x*40/100
    total=x+bonus
    print ("your total salary is",total)
else :
    bonus=x*20/100
    total=x+bonus
    print ("your total salary is",total)