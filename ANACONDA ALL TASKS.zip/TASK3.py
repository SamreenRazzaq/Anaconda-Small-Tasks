# -*- coding: utf-8 -*-
"""
Created on Fri Mar 18 19:43:32 2022

@author: DELL
"""

miles=int(input("enter number in miles: "))
kilo=(miles/1.6)
print("number in km is: ",kilo)