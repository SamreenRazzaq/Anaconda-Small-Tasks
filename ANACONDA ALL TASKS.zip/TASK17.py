# -*- coding: utf-8 -*-
"""
Created on Fri Mar 18 20:03:12 2022

@author: DELL
"""

print("Block of Stars")
for i in range(5):
    for j in range(5):
        print("*",end=' ')
    print()