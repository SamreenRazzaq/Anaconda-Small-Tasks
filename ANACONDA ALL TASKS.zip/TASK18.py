# -*- coding: utf-8 -*-
"""
Created on Fri Mar 18 20:04:08 2022

@author: DELL
"""

print("Right angle Triangle")
for i in range(5) :
    for j in range(i+1):
        print("*",end=' ')
    print()