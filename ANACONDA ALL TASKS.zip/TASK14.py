# -*- coding: utf-8 -*-
"""
Created on Fri Mar 18 19:57:54 2022

@author: DELL
"""

x = int(input("enter a number to find factorial: "))
y = 1
for i in range(1,x+1):
    y = y * i
print("factorial of a number is:  ",y)