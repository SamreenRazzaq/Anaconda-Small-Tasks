# -*- coding: utf-8 -*-
"""
Created on Fri Mar 18 19:49:22 2022

@author: DELL
"""

x = int(input("english subject's number is = "))
y = int(input("math subject's number is = "))
z = int(input("urdu subject's number is = "))
if ((x+y+z)/3 >= 75):
    print("admission granted")
else:
    print("you are above standard")