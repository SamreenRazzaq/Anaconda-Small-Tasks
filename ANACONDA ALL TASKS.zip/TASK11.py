# -*- coding: utf-8 -*-
"""
Created on Fri Mar 18 19:52:21 2022

@author: DELL
"""

x=1
while (x<=5):
    print ("Pakistan")
    x=x+1