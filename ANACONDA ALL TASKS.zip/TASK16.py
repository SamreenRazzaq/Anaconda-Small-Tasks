# -*- coding: utf-8 -*-
"""
Created on Fri Mar 18 20:01:00 2022

@author: DELL
"""

x=int(input("Enter number: "))
for i in range(x):
    if(x%2==0):
        print("%d is even number: "%x)
        y=int(input("Enter next number: "))
        if(y%2==0):
            print("%d is even number "%y)
            break
        break
        print("your number is odd")