# -*- coding: utf-8 -*-
"""
Created on Fri Mar 18 19:42:49 2022

@author: DELL
"""

print("    *     ")
print("   ***    ")
print("  *****   ")
print(" *******  ")
print("********* ")